## Test environments
* local OS X install, R 3.2.1
* win-builder

# R CMD check results
No NOTEs or WARNINGs.


